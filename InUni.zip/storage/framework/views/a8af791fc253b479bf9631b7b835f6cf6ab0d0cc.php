<link rel="stylesheet" href="<?php echo e(asset('public')); ?>/css/fontawesome.min.css">
<link rel="stylesheet" href="<?php echo e(asset('public')); ?>/css/odometer.min.css">
<link rel="stylesheet" href="<?php echo e(asset('public')); ?>/css/fancybox.min.css">
<link rel="stylesheet" href="<?php echo e(asset('public')); ?>/css/swiper.min.css">
<link rel="stylesheet" href="<?php echo e(asset('public')); ?>/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(asset('public')); ?>/css/style.css">
<?php /**PATH C:\inetpub\vhosts\inuni.xyz\httpdocs\resources\views/partials/style.blade.php ENDPATH**/ ?>