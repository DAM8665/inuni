<nav class="navbar">
    <figure><img src="<?php echo e(asset('public')); ?>/images/title-shape.png" alt="Image"></figure>
    <!-- end logo -->
    <div class="custom-menu">
        <ul>
            <li><a href="#">Eng</a></li>
            <li><a href="#">Fa</a></li>
        </ul>
    </div>
    <!-- end custom-menu -->
    <div class="site-menu" style="margin-right: auto">
        <ul>
            <li><a href="<?php echo e(route('index')); ?>">Home</a></li>
            <li><a href="#">Universities</a></li>
            <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
        </ul>
    </div>
    <!-- end site-menu -->
    <div class="hamburger-menu">
        <svg class="hamburger" width="30" height="30" viewBox="0 0 30 30">
            <path class="line line-top" d="M0,9h30"/>
            <path class="line line-center" d="M0,15h30"/>
            <path class="line line-bottom" d="M0,21h30"/>
        </svg>
    </div>
    <!-- end hamburger-menu -->
    <div class="navbar-button"><a href="<?php echo e(asset('public')); ?>/membership.html">SIGN UP</a></div>
    <!-- end navbar-button -->
</nav>
<?php /**PATH C:\inetpub\vhosts\inuni.xyz\httpdocs\resources\views/partials/navbar.blade.php ENDPATH**/ ?>