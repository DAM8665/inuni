<div class="page-transition">
    <svg viewBox="0 0 1920 1080" preserveAspectRatio="none" version="1.1">
        <path d="M0,0 C305.333333,0 625.333333,0 960,0 C1294.66667,0 1614.66667,0 1920,0 L1920,1080 C1614.66667,980 1294.66667,930 960,930 C625.333333,930 305.333333,980 0,1080 L0,0 Z"></path>
    </svg>
</div><?php /**PATH C:\inetpub\vhosts\inuni.xyz\httpdocs\resources\views/partials/transition.blade.php ENDPATH**/ ?>