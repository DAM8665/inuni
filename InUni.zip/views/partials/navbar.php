<nav class="navbar">
    <figure><img src="../../src/images/title-shape.png" alt="Image"></figure>
    <!-- end logo -->
    <div class="custom-menu">
        <ul>
            <li><a href="#">Eng</a></li>
            <li><a href="#">Per</a></li>
        </ul>
    </div>
    <!-- end custom-menu -->
    <div class="site-menu" style="margin-right: auto">
        <ul>
            <li><a href="<?php echo \App\Functions::route('universities') ?>">Universities</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
        </ul>
    </div>
    <!-- end site-menu -->
    <div class="hamburger-menu">
        <svg class="hamburger" width="30" height="30" viewBox="0 0 30 30">
            <path class="line line-top" d="M0,9h30"/>
            <path class="line line-center" d="M0,15h30"/>
            <path class="line line-bottom" d="M0,21h30"/>
        </svg>
    </div>
    <!-- end hamburger-menu -->
    <div class="navbar-button"><a href="../../src/membership.html">SIGN UP</a></div>
    <!-- end navbar-button -->
</nav>