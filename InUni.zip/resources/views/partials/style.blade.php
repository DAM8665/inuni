<link rel="stylesheet" href="{{asset('public')}}/css/fontawesome.min.css">
<link rel="stylesheet" href="{{asset('public')}}/css/odometer.min.css">
<link rel="stylesheet" href="{{asset('public')}}/css/fancybox.min.css">
<link rel="stylesheet" href="{{asset('public')}}/css/swiper.min.css">
<link rel="stylesheet" href="{{asset('public')}}/css/bootstrap.min.css">
<link rel="stylesheet" href="{{asset('public')}}/css/style.css">
